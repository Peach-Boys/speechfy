import MswInitializer from '@/components/common/MswInitializer';

export default function Home() {
  // 수정 가능한 페이지, 테스트를 위해 app/page.tsx를 많이 건드릴 예정입니다.
  return (
    <>
      <MswInitializer />
      <div>Home</div>
    </>
  );
}
