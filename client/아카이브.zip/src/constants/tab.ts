export const ROUTE_TABS = [
  { tabSrc: 'work', tabName: '작업' },
  { tabSrc: 'gerne', tabName: '장르' },
  { tabSrc: 'complete', tabName: '완성' },
];
