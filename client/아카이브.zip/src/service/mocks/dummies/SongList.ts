export const DUMMY_AI_SONGS = [
  {
    songId: 1,
    songSrc: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    instruments: [
      { id: 1, label: '기타' },
      { id: 2, label: '피아노' },
      { id: 3, label: '드럼' },
    ],
    gerne: '힙합',
    mood: '평화로운',
  },
  {
    songId: 2,
    songSrc: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    instruments: [
      { id: 1, label: '기타' },
      { id: 2, label: '피아노' },
      { id: 3, label: '드럼' },
    ],
    gerne: '힙합',
    mood: '평화로운',
  },
  {
    songId: 3,
    songSrc: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    instruments: [
      { id: 1, label: '기타' },
      { id: 2, label: '피아노' },
      { id: 3, label: '드럼' },
    ],
    gerne: '힙합',
    mood: '평화로운',
  },
  {
    songId: 4,
    songSrc: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    instruments: [
      { id: 1, label: '기타' },
      { id: 2, label: '피아노' },
      { id: 3, label: '드럼' },
    ],
    gerne: '힙합',
    mood: '평화로운',
  },
];
